package com.game.gamerummy;

import android.content.ClipData;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;
import androidx.databinding.ObservableArrayList;
import androidx.databinding.ObservableList;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

import com.game.gamerummy.databinding.ChooseExerciseItemBinding;
import com.game.gamerummy.databinding.SelectedExerciseItemBinding;


public class Adapter extends RecyclerView.Adapter<Adapter.ProjectHolder> {

    private ObservableList<ExcercisePojo> exerciseObservableList = new ObservableArrayList<>();
    private Context context;
    private RecyclerView recyclerExercise;
    private int layoutId;

    public Adapter(RecyclerView recyclerExercise, ObservableArrayList<ExcercisePojo> exerciseObservableList,int layoutId) {
        this.exerciseObservableList = exerciseObservableList;
        this.recyclerExercise = recyclerExercise;
        this.layoutId = layoutId;
    }

    @Override
    public ProjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layoutId, parent, false);
        context = parent.getContext();
        return new ProjectHolder(v);
    }

    @Override
    public void onBindViewHolder(ProjectHolder holder, int position) {
        final ExcercisePojo excercisePojo = exerciseObservableList.get(position);

        if (layoutId == R.layout.layout_choose_exercise_item) {
            ChooseExerciseItemBinding chooseExerciseItemBinding = (ChooseExerciseItemBinding) holder.chooseExerciseItemBinding;

            String str = excercisePojo.name;
            System.out.println(str);
            StringBuffer suit = new StringBuffer(),
                    valu = new StringBuffer();
            for (int i = 0; i < str.length(); i++) {
                if (Character.isDigit(str.charAt(i)))
                    valu.append(str.charAt(i));
                else if (Character.isAlphabetic(str.charAt(i)))
                    suit.append(str.charAt(i));
            }
            String suite = suit.toString();
            String value = String.valueOf(valu);
            cards(suite, Integer.parseInt(value), chooseExerciseItemBinding.imgg);
            chooseExerciseItemBinding.setChooseExerciseListAdapter(this);
        } else {
            SelectedExerciseItemBinding selectedExerciseItemBinding = (SelectedExerciseItemBinding) holder.chooseExerciseItemBinding;
            String str = excercisePojo.name;
            System.out.println(str);
            StringBuffer suit = new StringBuffer(),
                    valu = new StringBuffer();
            for (int i = 0; i < str.length(); i++) {
                if (Character.isDigit(str.charAt(i)))
                    valu.append(str.charAt(i));
                else if (Character.isAlphabetic(str.charAt(i)))
                    suit.append(str.charAt(i));
            }
            String suite = suit.toString();
            String value = String.valueOf(valu);
            cards(suite, Integer.parseInt(value), selectedExerciseItemBinding.imgg);
            selectedExerciseItemBinding.setChooseExerciseListAdapter(this);
        }

        holder.chooseExerciseItemBinding.executePendingBindings();
    }

    @Override
    public int getItemCount() {
        if (exerciseObservableList == null) {
            return 0;
        }
        return exerciseObservableList.size();
    }

    public class ProjectHolder extends RecyclerView.ViewHolder {
        public ViewDataBinding chooseExerciseItemBinding;

        public ProjectHolder(View itemView) {
            super(itemView);
            chooseExerciseItemBinding = DataBindingUtil.bind(itemView);
        }
    }


    public boolean onLongClick(View view) {
        ClipData data = ClipData.newPlainText("", "");
        View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
        view.startDrag(data, shadowBuilder, view, 0);
        view.setVisibility(View.INVISIBLE);
        if (layoutId == R.layout.layout_choose_exercise_item) {
            Host.isFromExercise = true;
            Client.isFromExercise = true;
        } else {
            Host.isFromExercise = false;
            Client.isFromExercise = false;
        }
        return true;
    }
    private void cards(String suite, int value, ImageView img) {
        if (suite.equals("hearts")) {
            switch (value) {
                case 1:
                    img.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 2:
                    img.setImageResource(R.drawable.f2_of_hearts);
                    break;
                case 3:
                    img.setImageResource(R.drawable.f3_of_hearts);
                    break;
                case 4:
                    img.setImageResource(R.drawable.f4_of_hearts);
                    break;
                case 5:
                    img.setImageResource(R.drawable.f5_of_hearts);
                    break;
                case 6:
                    img.setImageResource(R.drawable.f6_of_hearts);
                    break;
                case 7:
                    img.setImageResource(R.drawable.f7_of_hearts);
                    break;
                case 8:
                    img.setImageResource(R.drawable.f8_of_hearts);
                    break;
                case 9:
                    img.setImageResource(R.drawable.f9_of_hearts);
                    break;
                case 10:
                    img.setImageResource(R.drawable.f10_of_hearts);
                    break;
                case 11:
                    img.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 12:
                    img.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 13:
                    img.setImageResource(R.drawable.king_of_hearts);
                    break;
            }
        }
        if (suite.equals("clubs")) {
            switch (value) {

                case 1:
                    img.setImageResource(R.drawable.ace_of_clubs);
                    break;
                case 2:
                    img.setImageResource(R.drawable.f2_of_clubs);
                    break;
                case 3:
                    img.setImageResource(R.drawable.f3_of_clubs);
                    break;
                case 4:
                    img.setImageResource(R.drawable.f4_of_clubs);
                    break;
                case 5:
                    img.setImageResource(R.drawable.f5_of_clubs);
                    break;
                case 6:
                    img.setImageResource(R.drawable.f6_of_clubs);
                    break;
                case 7:
                    img.setImageResource(R.drawable.f7_of_clubs);
                    break;
                case 8:
                    img.setImageResource(R.drawable.f8_of_clubs);
                    break;
                case 9:
                    img.setImageResource(R.drawable.f9_of_clubs);
                    break;
                case 10:
                    img.setImageResource(R.drawable.f10_of_clubs);
                    break;
                case 11:
                    img.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 12:
                    img.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 13:
                    img.setImageResource(R.drawable.king_of_clubs);
                    break;
            }
        }
        if (suite.equals("spades")) {
            switch (value) {

                case 1:
                    img.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 2:
                    img.setImageResource(R.drawable.f2_of_spades);
                    break;
                case 3:
                    img.setImageResource(R.drawable.f3_of_spades);
                    break;
                case 4:
                    img.setImageResource(R.drawable.f4_of_spades);
                    break;
                case 5:
                    img.setImageResource(R.drawable.f5_of_spades);
                    break;
                case 6:
                    img.setImageResource(R.drawable.f6_of_spades);
                    break;
                case 7:
                    img.setImageResource(R.drawable.f7_of_spades);
                    break;
                case 8:
                    img.setImageResource(R.drawable.f8_of_spades);
                    break;
                case 9:
                    img.setImageResource(R.drawable.f9_of_spades);
                    break;
                case 10:
                    img.setImageResource(R.drawable.f10_of_spades);
                    break;
                case 11:
                    img.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 12:
                    img.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 13:
                    img.setImageResource(R.drawable.king_of_spades);
                    break;
            }
        }
        if (suite.equals("diamonds")) {
            switch (value) {
                case 1:
                    img.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 2:
                    img.setImageResource(R.drawable.f2_of_diamonds);
                    break;
                case 3:
                    img.setImageResource(R.drawable.f3_of_diamonds);
                    break;
                case 4:
                    img.setImageResource(R.drawable.f4_of_diamonds);
                    break;
                case 5:
                    img.setImageResource(R.drawable.f5_of_diamonds);
                    break;
                case 6:
                    img.setImageResource(R.drawable.f6_of_diamonds);
                    break;
                case 7:
                    img.setImageResource(R.drawable.f7_of_diamonds);
                    break;
                case 8:
                    img.setImageResource(R.drawable.f8_of_diamonds);
                    break;
                case 9:
                    img.setImageResource(R.drawable.f9_of_diamonds);
                    break;
                case 10:
                    img.setImageResource(R.drawable.f10_of_diamonds);
                    break;
                case 11:
                    img.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 12:
                    img.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 13:
                    img.setImageResource(R.drawable.king_of_diamonds);
                    break;
            }

        }
    }


}
