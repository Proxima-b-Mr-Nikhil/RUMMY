package com.game.gamerummy;
public class ExcercisePojo {
    public int exerciseId;
    public String name;

    public ExcercisePojo(int exerciseId, String name) {
        this.exerciseId = exerciseId;
        this.name = name;

    }
}
