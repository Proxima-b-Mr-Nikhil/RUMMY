package com.game.gamerummy;



import android.os.Bundle;

import android.view.DragEvent;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ObservableArrayList;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.game.gamerummy.ExcercisePojo;
import com.game.gamerummy.R;
import com.game.gamerummy.SpaceItemDecoration;
import com.game.gamerummy.databinding.ClientBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;


public class Client extends AppCompatActivity implements View.OnDragListener {
    DatabaseReference reference=FirebaseDatabase.getInstance().getReference("rummy");
    private jokercardAdapter mjokerAdapter;
    private opencardsAdapter mopenAdapter;
    List<String> remainingcards=new ArrayList<>();
    List<String> remaining=new ArrayList<>();
    List<String> player2=new ArrayList<>();
    List<String> handcards=new ArrayList<>();
    List<String> joker=new ArrayList<>();
    List<String> opencards=new ArrayList<>();
    public RecyclerView handRecyclerView,jokerRecyclerView,openRecyclerView;
    ImageView backofcard;

    private ClientBinding mainActivityBinding;
    public ObservableArrayList<ExcercisePojo> exerciseList;
    public ObservableArrayList<ExcercisePojo> exerciseSelectedList = new ObservableArrayList<>();
    public ExcercisePojo exerciseToMove;
    private int newContactPosition = -1;

    private int currentPosition = -1;
    private boolean isExerciseAdded = false;
    public static boolean isFromExercise = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivityBinding = DataBindingUtil.setContentView(this, R.layout.activity_client);
        exerciseList = new ObservableArrayList<>();
        loadExerciseData();
        mainActivityBinding.setClient(this);
        mainActivityBinding.set1.setOnDragListener(this);
        mainActivityBinding.handcard.setOnDragListener(new MyDragInsideRcvListener());
        int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.scale_3dp);
        mainActivityBinding.handcard.addItemDecoration(new SpaceItemDecoration(spacingInPixels));


        backofcard=findViewById(R.id.backofcard);


        handRecyclerView = findViewById(R.id.handcard);
        openRecyclerView = findViewById(R.id.opencard);
        jokerRecyclerView= findViewById(R.id.topCard);

        handRecyclerView.setHasFixedSize(true);
        openRecyclerView.setHasFixedSize(true);
        jokerRecyclerView.setHasFixedSize(true);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        LinearLayoutManager mLayoutManage = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        LinearLayoutManager mLayoutManag = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false);
        handRecyclerView.setLayoutManager(mLayoutManager);
        jokerRecyclerView.setLayoutManager(mLayoutManage);
        openRecyclerView.setLayoutManager(mLayoutManag);





    }


    public void loadExerciseData() {
        reference.child("player2").removeValue();

        reference.child("remaining").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                player2.clear();

                for (DataSnapshot snap : snapshot.getChildren()) {
                    remainingcards.add(String.valueOf(snap.getValue()));
                }
                for (int i=0;i<13;i++){
                    int r=new Random().nextInt(remainingcards.size());
                    player2.add(remainingcards.get(r));
                    remainingcards.remove(r);
                }
                System.out.println(player2.size());
                reference.child("player2").setValue(player2);
                reference.child("remaining").removeValue();
                reference.child("remaining").setValue(remainingcards);


                reference.child("player2").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()){

                            handcards.clear();
                            for (DataSnapshot snap : snapshot.getChildren()) {
                                handcards.add(String.valueOf(snap.getValue()));
                            }


                            if (handcards.size() > 0){

                                for (int i = 0; i <handcards.size(); i++) {
                                    exerciseList.add(new ExcercisePojo(i,handcards.get(i)));
                                }
                                // handRecyclerView.addItemDecoration(decoration);
                             //   handRecyclerView.setAdapter(mhandAdapter);


                            }}
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


        reference.child("joker").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    joker.add(Objects.requireNonNull(snapshot.getValue()).toString());

                    mjokerAdapter = new jokercardAdapter(getApplicationContext(), joker);

                    jokerRecyclerView.setAdapter(mjokerAdapter);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        reference.child("opencard").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    opencards.clear();
                    opencards.add(Objects.requireNonNull(snapshot.getValue()).toString());

                    mopenAdapter = new opencardsAdapter(getApplicationContext(), opencards);

                    openRecyclerView.setAdapter(mopenAdapter);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



    }

    @Override
    public boolean onDrag(View view, DragEvent dragEvent) {
        View selectedView = (View) dragEvent.getLocalState();
        RecyclerView rcvSelected = (RecyclerView) view;

        try {
            int currentPosition = mainActivityBinding.handcard.getChildAdapterPosition(selectedView);

            // Ensure the position is valid.
            if (currentPosition != -1) {
                exerciseToMove = exerciseList.get(currentPosition);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        switch (dragEvent.getAction()) {
            case DragEvent.ACTION_DRAG_LOCATION:
                View onTopOf = rcvSelected.findChildViewUnder(dragEvent.getX(), dragEvent.getY());
                newContactPosition = rcvSelected.getChildAdapterPosition(onTopOf);
                break;
            case DragEvent.ACTION_DRAG_ENTERED:
                break;
            case DragEvent.ACTION_DRAG_EXITED:
                break;
            case DragEvent.ACTION_DROP:
                //when Item is dropped off to recyclerview.
                if (isFromExercise) {
                    exerciseSelectedList.add(exerciseToMove);
                    exerciseList.remove(exerciseToMove);
                    mainActivityBinding.handcard.getAdapter().notifyItemRemoved(currentPosition);
                    mainActivityBinding.executePendingBindings();
                }

                break;

            case DragEvent.ACTION_DRAG_ENDED:
                // Reset the visibility for the Contact item's view.
                // This is done to reset the state in instances where the drag action didn't do anything.
                selectedView.setVisibility(View.VISIBLE);
                // Boundary condition, scroll to top is moving list item to position 0.
                if (newContactPosition != -1) {
                    rcvSelected.scrollToPosition(newContactPosition);
                    newContactPosition = -1;
                } else {
                    rcvSelected.scrollToPosition(0);
                }
            default:
                break;
        }
        return true;
    }

    /**
     * This listener class is for Vertical Recyclerview.
     */
    class MyDragInsideRcvListener implements View.OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            int action = event.getAction();
            RecyclerView rcv = (RecyclerView) v;

            View selectedView = (View) event.getLocalState();
            try {
                int currentPosition = rcv.getChildAdapterPosition(selectedView);
                // Ensure the position is valid.
                if (currentPosition != -1) {
                    exerciseToMove = exerciseSelectedList.get(currentPosition);
                    //exerciseSelectedList.get(currentPosition);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_LOCATION:
                    View onTopOf = rcv.findChildViewUnder(event.getX(), event.getY());
                    newContactPosition = rcv.getChildAdapterPosition(onTopOf);

                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                    // Reset the visibility for the Contact item's view.
                    // This is done to reset the state in instances where the drag action didn't do anything.
                    selectedView.setVisibility(View.VISIBLE);
                    // Boundary condition, scroll to top is moving list item to position 0.
                    if (newContactPosition != -1) {
                        rcv.scrollToPosition(newContactPosition);
                        newContactPosition = -1;
                    } else {
                        rcv.scrollToPosition(0);
                    }
                    break;
                case DragEvent.ACTION_DROP:
                    if (!isFromExercise) {
                        //THIS IS FOR WHEN WE TAKE ITEM OF OTHER LIST AND DROP IN THIS LIST.
                        exerciseList.add(exerciseToMove);
                        exerciseSelectedList.remove(exerciseToMove);
                        mainActivityBinding.handcard.getAdapter().notifyItemInserted(currentPosition);
                        mainActivityBinding.executePendingBindings();
                    }
                    break;

                default:
                    break;
            }
            return true;
        }
    }
}

