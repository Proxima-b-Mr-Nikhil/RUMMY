package com.game.gamerummy;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private int dif=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button but = (Button) findViewById(R.id.start);
        if (but != null) {
            but.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(MainActivity.this, Host.class);
                    startActivity(intent);

                }
            });
        }
        Button bu = (Button) findViewById(R.id.client);
        if (bu != null) {
            bu.setOnClickListener(v -> {

                Intent inten = new Intent(MainActivity.this, Client.class);
                startActivity(inten);

            });
        }


    }

}
